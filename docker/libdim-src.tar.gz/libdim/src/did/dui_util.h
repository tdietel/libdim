#ifndef DUI_UTIL_H
#define DUI_UTIL_H

#include "dui_colors.h"


#endif
